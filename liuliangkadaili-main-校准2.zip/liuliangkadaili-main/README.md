# 🚀 2025年最新流量卡套餐实时更新
**最后更新时间**: 2025-04-08 09:39:08

## 📡 中国电信套餐
| 套餐名称 | 月租 | 通用流量 | 定向流量 | 通话 | 区域限制 | 立即办理 |
|---------|------|----------|----------|------|----------|----------|
| 20.çµä¿¡æå¡29åå155Géç¨æµé+30Gå®åæµé+0.1å/åééè¯ | 29元 | 155G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=hO1pY2Dsvr) |
| 11.çµä¿¡æå¡29åå205Géç¨æµé+30Gå®åæµé+100åééè¯ | 29元 | 205G | 30G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=y0CkCQ6t1f) |
| 28.çµä¿¡æå¡19åå155Géç¨æµé+30Gå®åæµé+100åéåè´¹éè¯ï¼ä»åæ¹åï¼ | 19元 | 155G | 30G | 100分钟 | 湖南省内 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=rYaedmvj81) |
| 26.çµä¿¡æå¡29åå105Gå¨å½éç¨æµé+30Gå®åæµé+0.1å/åééè¯ | 29元 | 105G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=kxKfWHsgCU) |
| 25.çµä¿¡æå¡29åå105Gå¨å½éç¨æµé+30Gå®åæµé+0.1å/åééè¯(ä»åæ¹å) | 29元 | 105G | 30G | 0.1元/分钟 | 湖南 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=H45j48yzHk) |
| 24.çµä¿¡æå¡29åå155Géç¨æµé+30Gå®åæµé+0.1å/åééè¯ï¼ä»åæ¹åï¼ | 29元 | 155G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=M3NUaYDVQ3) |
| 23.çµä¿¡æå¡29åå155Géç¨æµé+30Gå®åæµé+100åéåè´¹éè¯ï¼ä»åæ¹åï¼ | 29元 | 155G | 30G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=cOd8OBtd8A) |
| 21.çµä¿¡æå¡29åå205Géç¨æµé+30Gå®åæµé+100åéåè´¹éè¯ï¼ä»åå¹¿ä¸ï¼ | 29元 | 205G | 30G | 100分钟 | 广东 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=VdREZdQG3X) |
| 18.çµä¿¡æå¡29åå100Géç¨æµé+30Gå®åæµé+0.1å/åééè¯ | 29元 | 100G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=tH2Oll1Yqg) |
| 15.çµä¿¡æå¡29åå105Géç¨æµé+30Gå®åæµé+éè¯0.1å/åé | 29元 | 105G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=ar805xXmDN) |
| 14.çµä¿¡æå¡29åå50Gå¨å½éç¨æµé+30Gå®åæµé+0.1å/åééè¯(ä»åæ¹åçå) | 29元 | 50G | 30G | 0.1元/分钟 | 湖北 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=XjqfLgm4VE) |
| 13.çµä¿¡æå¡29åå50Gå¨å½éç¨æµé+30Gå®åæµé+0.1å/åééè¯ | 29元 | 80G | 30G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=Bpx8IHjU4V) |
| çµä¿¡æå¿å¡19åå205Géç¨æµé+30Gå®åæµé+100åéåè´¹éè¯(åå¨å½) | 19元 | 205G | 30G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=j1vZCEhNQy) |

## 📶 中国联通套餐
| 套餐名称 | 月租 | 通用流量 | 定向流量 | 通话 | 区域限制 | 立即办理 |
|---------|------|----------|----------|------|----------|----------|
| åä¼äººæ¿ç­ï¼æ¬¢è¿æ´½è°ï¼å¾®ä¿¡äºç»´ç å¨è¯¦æé¡µ | 1元 | 1G | 1G | 1分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=Qm9SpxyHEe) |
| 1.èéæ¥é£å¡39åå280Géç¨æµé+100åéåè´¹éè¯ | 39元 | 280G | 0G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=rxBOkkWpD1) |
| 2.èéåå·å¡29åå160Géç¨æµé+100åéåè´¹éè¯ï¼ä»ååå·ï¼ | 29元 | 160G | 0G | 100分钟 | 四川省内 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=9CgFlRuO1z) |
| 1.èéåå·å¡39åå215Géç¨æµé+100åéåè´¹éè¯ï¼ä»ååå·ï¼ | 39元 | 215G | 0G | 100分钟 | 四川省内 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=KCBopQou3x) |
| èéä¸æµ·å¡19åå215Géç¨æµé+20Gå®åæµé+100åéåè´¹éè¯ï¼ä»åä¸æµ·ï¼ | 19元 | 215G | 20G | 100分钟 | 上海 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=7zlq8q0IGo) |
| èééé¾å¡19åå158Géç¨æµé+30Gå®åæµé+10.1å/åééè¯ï¼ä»åéè¥¿ï¼ | 19元 | 158G | 30G | 0.1元/分钟 | 陕西 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=LAEEgX3Fap) |
| 2.èéæµ·åå¡49åå320Géç¨æµé+30Gå®åæµé+éè¯0.1å/åéï¼ä»åæµ·åï¼ | 49元 | 320G | 30G | 0.1元/分钟 | 海南 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=vq9gY2hiDn) |
| 1.èéæµ·åå¡29åå205Géç¨æµé+30Gå®åæµé+éè¯0.1å/åéï¼ä»åæµ·åï¼ | 29元 | 205G | 30G | 0.1元/分钟 | 海南 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=azKEJkJ2Bs) |
| èééè¥¿å¡19åå158Géç¨æµé+30Gå®åæµé+éè¯0.1å/åéï¼ä»åéè¥¿ï¼ | 19元 | 158G | 30G | 0.1元/分钟 | 陕西 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=hBlWZClrpq) |
| èéå½©äºå¡29åå80Géç¨æµé+éè¯0.15å/åéï¼ä»åäºåï¼ | 29元 | 80G | 0G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=iBaov04AGm) |
| èéèç¨å¡39åå210Géç¨æµé+100åééè¯ï¼ä»åæ±èçåï¼ | 39元 | 210G | 0G | 100分钟 | 江苏 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=NRUpgQP5bK) |
| èéäº«éå¡29åå135Géç¨æµé+100åéåè´¹éè¯ï¼æ¶è´§å°å³å½å±å°ï¼ | 29元 | 135G | 0G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=C48tEK05S1) |
| èééé¾å¡39åå219Géç¨æµé+100åéåè´¹éè¯ï¼ä»åå¹¿è¥¿ï¼ | 39元 | 219G | 0G | 100分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=2xrKqOvmQf) |
| èééé¾å¡29åå219Géç¨æµé+100åéåè´¹éè¯ï¼ä»åå¹¿è¥¿ï¼ | 29元 | 219G | 0G | 100分钟 | 广西 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=Z0Run1T7yn) |
| èéå®½å¸¦å¡139åå200Géç¨æµé+500åéåè´¹éè¯+1000Må®½å¸¦+è§é¢ä¼åï¼é¿æå¥é¤ï¼ä»åæµæ±ï¼ | 139元 | 200G | 0G | 500分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=oFPFZ1oGtH) |

## 📱 中国移动套餐
| 套餐名称 | 月租 | 通用流量 | 定向流量 | 通话 | 区域限制 | 立即办理 |
|---------|------|----------|----------|------|----------|----------|
| 2.ç§»å¨ä¸æµ·å¡29åå245Géç¨æµé+100åéåè´¹éè¯ï¼ä»åä¸æµ·ï¼ | 29元 | 245G | 0G | 100分钟 | 上海 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=WOOkEdHlN7) |
| 1.ç§»å¨ä¸æµ·å¡19åå188Géç¨æµé+50åéåè´¹éè¯ï¼ä»åä¸æµ·ï¼ | 29元 | 188G | 0G | 50分钟 | 上海 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=ic1ousNQky) |

## 📺 广电套餐
| 套餐名称 | 月租 | 通用流量 | 定向流量 | 通话 | 区域限制 | 立即办理 |
|---------|------|----------|----------|------|----------|----------|
| 7.å¹¿çµæµæ±å¡38åå260Géç¨æµé+30Gå®åæµé+300åéåè´¹éè¯ | 38元 | 260G | 30G | 300分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=8EVAFAV2nu) |
| å¹¿çµæµæ±å¡29åå220Géç¨æµé+30Gå®åæµé+200åéåè´¹éè¯ | 28元 | 320G | 30G | 200分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=u59AGQmm5q) |
| 6.å¹¿çµæ­£é¾å¡29åå99Géç¨æµé+0.15å/åééè¯ | 29元 | 99G | 0G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=5w5j376mfq) |
| 5.å¹¿çµæ­£é¾å¡29åå99Géç¨æµé+0.15å/åééè¯ | 29元 | 99G | 0G | 0.1元/分钟 | 全国 | [立即办理](https://www.91haoka.cn/webapp/weixiaodian/index.html?shop_id=563381&fetch_code=dBgoIzoYnW) |

## 📌 重要说明
1. 标注"仅发XX"需核对收货地址
2. 0.1元/分钟为全国通话资费
3. 定向流量包含抖音/微信等30+APP

📞 客服微信: XKKJ66（备注「流量卡」）
